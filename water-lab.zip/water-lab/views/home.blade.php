<div>
    <div class="flex flex-col gap-6">
        <div class="container p-3 mx-auto rounded-md" style="background-color: rgb(155, 192, 223)">
            <article class="max-w-full prose dark:prose-invert">
                {!! Str::markdown(theme('home_page_text', 'Welcome to Paymenter'), [
                'allow_unsafe_links' => false,
                'renderer' => [
                    'soft_break' => "<br>"
                ]]) !!}
            </article>
        </div>
        <div class="container grid gap-4 mx-auto mb-4 rounded-md md:grid-cols-2 lg:grid-cols-4">
            @foreach ($categories as $category)
                <div class="flex flex-col p-4 border rounded-lg bg-background-secondary hover:bg-background-secondary/80 border-neutral">
                    @if(theme('small_images', false))
                        <div class="flex items-center gap-x-3">
                    @endif
                    @if ($category->image)
                        <img src="{{ Storage::url($category->image) }}" alt="{{ $category->name }}"
                            class="rounded-md {{ theme('small_images', false) ? 'w-14 h-fit' : 'w-full object-cover object-center' }}">
                    @endif
                    <h2 class="text-xl font-bold">{{ $category->name }}</h2>
                    @if(theme('small_images', false))
                        </div>
                    @endif
                    @if(theme('show_category_description', true))
                        <article class="mt-2 prose dark:prose-invert">
                            {!! $category->description !!}
                        </article>
                    @endif
                    <a href="{{ route('category.show', ['category' => $category->slug]) }}" wire:navigate class="mt-2">
                        <x-button.primary>
                            {{ __('general.view') }}
                        </x-button.primary>
                    </a>
                </div>
            @endforeach
        </div>
    </div>
    {!! hook('pages.home') !!}
</div>
