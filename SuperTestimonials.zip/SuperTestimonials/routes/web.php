<?php

use Illuminate\Support\Facades\Route;
use Paymenter\Extensions\Others\SuperTestimonials\Livewire\Testimonials\Index;
use Paymenter\Extensions\Others\SuperTestimonials\Livewire\Testimonials\Create;
use Paymenter\Extensions\Others\SuperTestimonials\Livewire\Testimonials\Show;

Route::group(['middleware' => ['web']], function () {
    Route::get('/testimonials', Index::class)->name('supertestimonials.index');
    Route::get('/testimonials/create', Create::class)->name('supertestimonials.create');
    Route::get('/testimonials/{testimonial}', Show::class)->name('supertestimonials.show');
});
