<?php

namespace Paymenter\Extensions\Others\SuperTestimonials\Livewire\Testimonials;

use Livewire\Component;
use Paymenter\Extensions\Others\SuperTestimonials\Models\Testimonial;

class Widget extends Component
{
    public function render()
    {
        return view('supertestimonials::widget', [
            'testimonials' => Testimonial::where('status', 'approved')->orderBy('created_at', 'desc')->limit(5)->get(),
        ]);
    }
}
