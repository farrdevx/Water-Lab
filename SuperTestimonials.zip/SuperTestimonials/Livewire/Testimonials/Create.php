<?php

namespace Paymenter\Extensions\Others\SuperTestimonials\Livewire\Testimonials;

use Livewire\Component;
use Paymenter\Extensions\Others\SuperTestimonials\Models\Testimonial;

class Create extends Component
{
    public $customer_name = '';
    public $testimonial_text = '';

    protected $rules = [
        'customer_name' => 'required|string|max:255',
        'testimonial_text' => 'required|string',
    ];

    public function submit()
    {
        $this->validate();

        Testimonial::create([
            'customer_name' => $this->customer_name,
            'testimonial_text' => $this->testimonial_text,
            'status' => 'pending',
        ]);

        session()->flash('message', 'Testimonial submitted successfully and is pending approval.');

        // Reset form fields
        $this->customer_name = '';
        $this->testimonial_text = '';
    }

    public function render()
    {
        return view('supertestimonials::create');
    }
}
