<?php

namespace Paymenter\Extensions\Others\SuperTestimonials\Livewire\Testimonials;

use Livewire\Component;
use Paymenter\Extensions\Others\SuperTestimonials\Models\Testimonial;

class Show extends Component
{
    public Testimonial $testimonial;

    public function mount()
    {
        // Only show approved testimonials
        if ($this->testimonial->status !== 'approved') {
            return abort(404);
        }
    }

    public function render()
    {
        // Use theme-aware view resolution
        return view('extensions.supertestimonials.show');
    }
}
