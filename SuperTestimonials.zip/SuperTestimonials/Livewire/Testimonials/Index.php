<?php

namespace Paymenter\Extensions\Others\SuperTestimonials\Livewire\Testimonials;

use Livewire\Component;
use Paymenter\Extensions\Others\SuperTestimonials\Models\Testimonial;

class Index extends Component
{
    public function mount()
    {
        if (Testimonial::where('status', 'approved')->count() == 0) {
            return abort(404);
        }
    }

    public function render()
    {
        $testimonials = Testimonial::where('status', 'approved')->orderBy('created_at', 'desc')->get();

        // Use theme-aware view resolution
        return view('extensions.supertestimonials.index', ['testimonials' => $testimonials]);
    }
}
