# SuperTestimonials Extension

A comprehensive testimonial management system for Paymenter that allows customers to submit testimonials and administrators to manage them with approval workflows.

## Features

- **Customer Testimonial Submission**: Customers can submit testimonials via a user-friendly form
- **Admin Management**: Full admin panel integration with approve/decline functionality
- **Individual Testimonial Pages**: Dedicated pages for each testimonial
- **Dashboard Widget**: Recent testimonials widget for the dashboard
- **Theme Customization**: Full theme override support for custom styling
- **Responsive Design**: Mobile-friendly layouts
- **Navigation Integration**: Automatic navbar link integration

## Installation

1. Enable the extension in the Paymenter admin panel
2. The extension will automatically run the database migration
3. Start collecting testimonials from your customers!

## Usage

### For Customers

- Visit `/testimonials` to view all approved testimonials
- Click on any testimonial to view the full content
- Use `/testimonials/create` to submit a new testimonial
- Submitted testimonials are pending approval by default

### For Administrators

- Access testimonials management via the admin panel
- Approve or decline pending testimonials
- Edit or delete testimonials as needed
- View all testimonials with their status (pending, approved, declined)

## Theme Customization

The SuperTestimonials extension supports full theme customization using Paymenter's theme system. Theme developers can override any view by creating corresponding files in their theme directory.

### How to Customize

1. Create the directory structure in your theme:

   ```
   themes/your-theme/views/extensions/supertestimonials/
   ```

2. Copy any of the following files from `themes/default/views/extensions/supertestimonials/` to your theme directory and modify as needed:
   - `index.blade.php` - Main testimonials listing page
   - `create.blade.php` - Testimonial submission form
   - `show.blade.php` - Individual testimonial display
   - `widget.blade.php` - Dashboard widget

### View Resolution Order

The extension uses the following view resolution order:

1. **Theme View**: `themes/{current-theme}/views/extensions/supertestimonials/{view}.blade.php`
2. **Extension View**: `extensions/Others/SuperTestimonials/resources/views/{view}.blade.php`

This means if you create a file in your theme's `views/extensions/supertestimonials/` directory, it will automatically override the default extension view.

### Available Variables

#### index.blade.php

- `$testimonials` - Collection of approved testimonials

#### create.blade.php

- `$customer_name` - Customer name input (Livewire property)
- `$testimonial_text` - Testimonial text input (Livewire property)
- `submit()` - Method to submit the form

#### show.blade.php

- `$testimonial` - The testimonial model instance

#### widget.blade.php

- `$testimonials` - Collection of recent approved testimonials (limited to 5)

### Example Theme Override

```php
// themes/your-theme/views/extensions/supertestimonials/index.blade.php
@if(count($testimonials) > 0)
<div class="my-custom-testimonials-container">
    <h1 class="my-custom-title">{{ __('Customer Reviews') }}</h1>

    @foreach($testimonials as $testimonial)
    <div class="my-custom-testimonial-card">
        <a href="{{ route('supertestimonials.show', $testimonial) }}">
            <h3>{{ $testimonial->customer_name }}</h3>
            <p>{{ Str::limit($testimonial->testimonial_text, 100) }}</p>
        </a>
    </div>
    @endforeach

    <a href="{{ route('supertestimonials.create') }}" class="my-custom-button">
        {{ __('Add Testimonial') }}
    </a>
</div>
@endif
```

### CSS Customization

Add your custom styles to your theme's CSS files:

```css
/* themes/your-theme/css/app.css */
.my-custom-testimonials-container {
  /* Your custom styles */
}

.my-custom-testimonial-card {
  /* Your custom card styles */
}
```

### Testing Theme Customization

1. Create a custom view file in your theme directory
2. Clear any caches: `php artisan cache:clear`
3. Visit the testimonials page to see your custom styling
4. The extension will automatically use your theme's view instead of the default

## Routes

The extension registers the following routes:

- `GET /testimonials` - List all approved testimonials
- `GET /testimonials/create` - Show testimonial submission form
- `GET /testimonials/{testimonial}` - Show individual testimonial

## Database

The extension creates a table `ext_testimonials` with the following structure:

- `id` - Primary key
- `customer_name` - Customer's name
- `testimonial_text` - The testimonial content
- `status` - Status (pending, approved, declined)
- `created_at` - Creation timestamp
- `updated_at` - Last update timestamp

## Events

The extension integrates with Paymenter's event system:

- **Navigation Event**: Adds "Testimonials" link to the main navigation
- **Dashboard Event**: Displays testimonials widget on the dashboard (supports theme override)
- **Home Page Event**: Shows testimonials on the home page (supports theme override)

## Example Theme Files

The extension includes example theme customization files in `themes/default/views/extensions/supertestimonials/` that demonstrate:

- **Enhanced Styling**: Beautiful gradients, shadows, and animations
- **Responsive Design**: Mobile-friendly layouts
- **Custom Icons**: SVG icons for better visual appeal
- **Interactive Elements**: Hover effects and transitions
- **Accessibility**: Proper semantic HTML and ARIA labels

These files serve as a starting point for your own customizations.

## Support

For support and customization help, please refer to the Paymenter documentation or community forums.

## License

This extension follows the same license as Paymenter.
