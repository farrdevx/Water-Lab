<?php

namespace Paymenter\Extensions\Others\SuperTestimonials;

use App\Classes\Extension\Extension;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\View;
use Illuminate\Support\HtmlString;
use Paymenter\Extensions\Others\SuperTestimonials\Admin\Resources\TestimonialResource;
use Paymenter\Extensions\Others\SuperTestimonials\Models\Testimonial;

class SuperTestimonials extends Extension
{
    public function getConfig($values = [])
    {
        try {
            return [
                [
                    'name' => 'Notice',
                    'type' => 'placeholder',
                    'label' => new HtmlString('You can use this extension to collect and display customer testimonials. To manage testimonials, go to <a class="text-primary-600" href="' . TestimonialResource::getUrl() . '">Testimonials</a>.'),
                ],
            ];
        } catch (\Exception $e) {
            return [
                [
                    'name' => 'Notice',
                    'type' => 'placeholder',
                    'label' => new HtmlString('You can use this extension to collect and display customer testimonials. You\'ll need to enable this extension above to get started.'),
                ],
            ];
        }
    }

    public function enabled()
    {
        Artisan::call('migrate', ['--path' => 'extensions/Others/SuperTestimonials/database/migrations/2024_10_19_000000_create_ext_testimonials_table.php', '--force' => true]);
    }

    public function boot()
    {
        require __DIR__ . '/routes/web.php';

        // Register extension views namespace
        View::addNamespace('supertestimonials', __DIR__ . '/resources/views');

        \Livewire\Livewire::component('supertestimonials.index', \Paymenter\Extensions\Others\SuperTestimonials\Livewire\Testimonials\Index::class);
        \Livewire\Livewire::component('supertestimonials.create', \Paymenter\Extensions\Others\SuperTestimonials\Livewire\Testimonials\Create::class);
        \Livewire\Livewire::component('supertestimonials.show', \Paymenter\Extensions\Others\SuperTestimonials\Livewire\Testimonials\Show::class);
        \Livewire\Livewire::component('supertestimonials.widget', \Paymenter\Extensions\Others\SuperTestimonials\Livewire\Testimonials\Widget::class);

        Event::listen('navigation', function () {
            return [
                'name' => 'Testimonials',
                'route' => 'supertestimonials.index',
                'icon' => 'ri-chat-quote-line',
                'separator' => true,
                'children' => [],
            ];
        });

        Event::listen('pages.home', function () {
            $testimonials = Testimonial::where('status', 'approved')->orderBy('created_at', 'desc')->get();

            // Use theme-aware view resolution
            return [
                'view' => view('extensions.supertestimonials.index', ['testimonials' => $testimonials]),
            ];
        });

        Event::listen('pages.dashboard', function () {
            $testimonials = Testimonial::where('status', 'approved')->orderBy('created_at', 'desc')->get();

            // Use theme-aware view resolution
            return [
                'view' => view('extensions.supertestimonials.widget', ['testimonials' => $testimonials]),
            ];
        });
    }
}
