<?php

namespace Paymenter\Extensions\Others\SuperTestimonials\Admin\Resources;

use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Paymenter\Extensions\Others\SuperTestimonials\Admin\Resources\TestimonialResource\Pages;
use Paymenter\Extensions\Others\SuperTestimonials\Models\Testimonial;

class TestimonialResource extends Resource
{
    protected static ?string $model = Testimonial::class;

    protected static ?string $navigationIcon = 'heroicon-o-chat-bubble-left-right';

    protected static ?string $activeNavigationIcon = 'heroicon-s-chat-bubble-left-right';

    protected static ?string $navigationGroup = 'Administration';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\TextInput::make('customer_name')
                    ->label('Customer Name')
                    ->required()
                    ->maxLength(255)
                    ->placeholder('Enter the customer name'),
                Forms\Components\Textarea::make('testimonial_text')
                    ->label('Testimonial Text')
                    ->required()
                    ->placeholder('Enter the testimonial text'),
                Forms\Components\Select::make('status')
                    ->label('Status')
                    ->options([
                        'pending' => 'Pending',
                        'approved' => 'Approved',
                        'declined' => 'Declined',
                    ])
                    ->required()
                    ->default('pending'),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('customer_name')
                    ->searchable()
                    ->sortable(),
                Tables\Columns\TextColumn::make('testimonial_text')
                    ->searchable()
                    ->limit(50),
                Tables\Columns\TextColumn::make('status')
                    ->searchable()
                    ->sortable(),
                Tables\Columns\TextColumn::make('created_at')
                    ->dateTime()
                    ->sortable(),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('status')
                    ->options([
                        'pending' => 'Pending',
                        'approved' => 'Approved',
                        'declined' => 'Declined',
                    ]),
            ])
            ->actions([
                Tables\Actions\Action::make('approve')
                    ->label('Approve')
                    ->icon('ri-check-line')
                    ->color('success')
                    ->requiresConfirmation()
                    ->action(function (Testimonial $record) {
                        $record->fill(['status' => 'approved']);
                        $record->save();
                    })
                    ->hidden(fn(Testimonial $record) => $record->status === 'approved'),
                Tables\Actions\Action::make('decline')
                    ->label('Decline')
                    ->icon('ri-close-line')
                    ->color('danger')
                    ->requiresConfirmation()
                    ->action(function (Testimonial $record) {
                        $record->fill(['status' => 'declined']);
                        $record->save();
                    })
                    ->hidden(fn(Testimonial $record) => $record->status === 'declined'),
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListTestimonials::route('/'),
            'create' => Pages\CreateTestimonial::route('/create'),
            'edit' => Pages\EditTestimonial::route('/{record}/edit'),
        ];
    }
}
