<?php

namespace Paymenter\Extensions\Others\SuperTestimonials\Admin\Resources\TestimonialResource\Pages;

use Filament\Resources\Pages\ListRecords;
use Paymenter\Extensions\Others\SuperTestimonials\Admin\Resources\TestimonialResource;

class ListTestimonials extends ListRecords
{
    protected static string $resource = TestimonialResource::class;

    protected function getHeaderActions(): array
    {
        return [
            // Add any header actions if needed
        ];
    }
}
