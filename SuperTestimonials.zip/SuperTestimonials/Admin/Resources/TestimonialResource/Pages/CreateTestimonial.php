<?php

namespace Paymenter\Extensions\Others\SuperTestimonials\Admin\Resources\TestimonialResource\Pages;

use Filament\Resources\Pages\CreateRecord;
use Paymenter\Extensions\Others\SuperTestimonials\Admin\Resources\TestimonialResource;

class CreateTestimonial extends CreateRecord
{
    protected static string $resource = TestimonialResource::class;
}
