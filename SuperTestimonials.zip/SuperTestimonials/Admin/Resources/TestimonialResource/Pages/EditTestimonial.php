<?php

namespace Paymenter\Extensions\Others\SuperTestimonials\Admin\Resources\TestimonialResource\Pages;

use Filament\Resources\Pages\EditRecord;
use Paymenter\Extensions\Others\SuperTestimonials\Admin\Resources\TestimonialResource;

class EditTestimonial extends EditRecord
{
    protected static string $resource = TestimonialResource::class;
}
