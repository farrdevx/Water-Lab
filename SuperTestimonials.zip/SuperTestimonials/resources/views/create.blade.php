<div class="container mx-auto mt-4">
    <h1 class="mb-2 text-xl font-bold">{{ __('Submit Testimonial') }}</h1>

    @if (session()->has('message'))
        <div class="relative px-4 py-3 mb-4 text-green-700 bg-green-100 border border-green-400 rounded" role="alert">
            <span class="block sm:inline">{{ session('message') }}</span>
        </div>
    @endif

    <form wire:submit.prevent="submit" class="space-y-4">
        <div>
            <label for="customer_name" class="block text-sm font-medium text-gray-700">{{ __('Your Name') }}</label>
            <input type="text" id="customer_name" wire:model="customer_name" class="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50">
            @error('customer_name') <span class="text-xs text-red-500">{{ $message }}</span> @enderror
        </div>

        <div>
            <label for="testimonial_text" class="block text-sm font-medium text-gray-700">{{ __('Testimonial') }}</label>
            <textarea id="testimonial_text" wire:model="testimonial_text" rows="4" class="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"></textarea>
            @error('testimonial_text') <span class="text-xs text-red-500">{{ $message }}</span> @enderror
        </div>

        <div>
            <x-button.primary type="submit">
                {{ __('Submit Testimonial') }}
            </x-button.primary>
        </div>
    </form>
</div>
