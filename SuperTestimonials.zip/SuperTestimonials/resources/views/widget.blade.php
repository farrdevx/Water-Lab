@if(count($testimonials) > 0)
<div class="p-4 rounded-lg bg-background-secondary">
    <h2 class="mb-2 text-lg font-bold">{{ __('Recent Testimonials') }}</h2>
    
    <div class="space-y-3">
        @foreach($testimonials->take(3) as $testimonial)
        <div class="pb-2 border-b border-neutral last:border-0 last:pb-0">
            <a href="{{ route('supertestimonials.show', $testimonial) }}" class="block hover:opacity-80">
                <p class="text-sm italic">"{{ Str::limit($testimonial->testimonial_text, 80) }}"</p>
                <p class="mt-1 text-xs">- {{ $testimonial->customer_name }}</p>
            </a>
        </div>
        @endforeach
    </div>
    
    @if($testimonials->count() > 3)
    <div class="mt-3 text-center">
        <a href="{{ route('supertestimonials.index') }}" class="text-sm text-primary hover:underline">
            {{ __('View All Testimonials') }}
        </a>
    </div>
    @endif
</div>
@endif
