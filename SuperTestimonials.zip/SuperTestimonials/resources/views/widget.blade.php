@if(count($testimonials) > 0)
<div class="p-4 rounded-lg bg-background-secondary">
    <h2 class="mb-2 text-lg font-bold">{{ __('Recent Testimonials') }}</h2>
    
    <div class="space-y-3">
        @foreach($testimonials as $testimonial)
        <div class="pb-2 border-b border-neutral last:border-0 last:pb-0">
            <p class="text-sm italic">"{{ $testimonial->testimonial_text }}"</p>
            <p class="mt-1 text-xs">- {{ $testimonial->customer_name }}</p>
        </div>
        @endforeach
    </div>
</div>
@endif
