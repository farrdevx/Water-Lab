<div class="mx-auto container mt-4">
    <div class="bg-background-secondary hover:bg-background-secondary/80 border border-neutral p-4 rounded-lg">
        <div class="flex flex-row justify-between mb-6">
            <h2 class="text-xl font-bold">{{ $testimonial->customer_name }}</h2>
            <p class="text-sm text-base">{{ $testimonial->created_at->diffForHumans() }}</p>
        </div>
        <article class="prose dark:prose-invert mb-2 max-w-full">
            <blockquote class="text-lg italic border-l-4 border-primary pl-4">
                "{{ $testimonial->testimonial_text }}"
            </blockquote>
            <p class="text-right mt-4 font-semibold">- {{ $testimonial->customer_name }}</p>
        </article>
    </div>
</div>
