@if(count($testimonials) > 0)
<div class="container mx-auto mt-4">
    
    <h1 class="mb-2 text-xl font-bold">{{ __('Testimonials') }}</h1>

    <div class="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
        @foreach($testimonials as $testimonial)
        <div class="p-4 border rounded-lg bg-background-secondary hover:bg-background-secondary/80 border-neutral">
            <h2 class="text-xl font-bold">{{ $testimonial->customer_name }}</h2>
            <div class="mb-2">
                {{ $testimonial->testimonial_text }}
            </div>
        </div>
        @endforeach
    </div>
</div>
@endif
