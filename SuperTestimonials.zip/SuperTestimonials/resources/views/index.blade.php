@if(count($testimonials) > 0)
<div class="container mx-auto mt-4">
    
    <h1 class="mb-2 text-xl font-bold">{{ __('Testimonials') }}</h1>

    <div class="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
        @foreach($testimonials as $testimonial)
        <div class="p-4 transition-colors border rounded-lg bg-background-secondary hover:bg-background-secondary/80 border-neutral">
            <a href="{{ route('supertestimonials.show', $testimonial) }}" class="block">
                <h2 class="text-xl font-bold">{{ $testimonial->customer_name }}</h2>
                <div class="mb-2">
                    {{ Str::limit($testimonial->testimonial_text, 100) }}
                </div>
                <p class="text-xs text-gray-500">{{ $testimonial->created_at->diffForHumans() }}</p>
            </a>
        </div>
        @endforeach
    </div>
    
    <div class="mt-6">
        <a href="{{ route('supertestimonials.create') }}" class="px-4 py-2 text-white rounded bg-primary hover:bg-primary-dark">
            {{ __('Add Your Testimonial') }}
        </a>
    </div>
</div>
@else
<div class="container mx-auto mt-4">
    <h1 class="mb-6 text-2xl font-bold">{{ __('Testimonials') }}</h1>
    <p class="mb-4">{{ __('No testimonials available yet.') }}</p>
    <a href="{{ route('supertestimonials.create') }}" class="px-4 py-2 text-white rounded bg-primary hover:bg-primary-dark">
        {{ __('Be the First to Add a Testimonial') }}
    </a>
</div>
@endif
