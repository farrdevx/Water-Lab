<?php

namespace Paymenter\Extensions\Others\SuperTestimonials\Models;

use Illuminate\Database\Eloquent\Model;

class Testimonial extends Model
{
    protected $table = 'ext_testimonials';

    protected $fillable = [
        'customer_name',
        'testimonial_text',
        'status',
    ];

    protected $casts = [
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}
